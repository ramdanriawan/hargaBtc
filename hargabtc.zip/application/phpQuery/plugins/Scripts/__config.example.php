<?php
/**
 * This file hosts config for Scripts plugin.
 *
 * To active this file, selete '.example' from filename.
 */
$config = array(
	'google_login' => array('login@mail', 'password'),
);
?>