<?php

echo file_get_contents(__DIR__."./dataExchanger.json");

 ?>
