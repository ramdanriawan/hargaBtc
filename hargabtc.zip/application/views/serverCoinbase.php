<?php

file_put_contents(__DIR__ . "./dataCoinbaseFile.json", $_GET["dataCoinbase"]);

 ?>
